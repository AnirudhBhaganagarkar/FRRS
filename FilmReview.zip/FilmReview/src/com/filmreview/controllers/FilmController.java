package com.filmreview.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.filmreview.models.AddFilm;
import com.filmreview.models.AddReview;
import com.filmreview.models.ReportFilms;
import com.filmreview.models.Review;
import com.filmreview.models.Updatefilm;
import com.filmreview.models.User;

@Controller
public class FilmController {
	@RequestMapping("/")
	public String home() {
		return "index";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/check")
	public String authenticate(User obj) {
		String page = "";
		if (obj.checkUser().equals("admin"))
			page = "AdminPanel";
		else if (obj.checkUser().equals("customer"))
			page = "UserHome";
		else
			page = "Failure";
		return page;
	}

	@RequestMapping("/Addnewfilm")
	public String addFilm() {
		return "Addnewfilm";
	}

	@RequestMapping("/addfilm")
	public String filmAdd(AddFilm objs) {
		String Page = "";
		if (objs.addFilmdeatils().equals("success"))
			Page = "NewFile";
		else
			Page = "Failure";

		return Page;
	}

	@RequestMapping("/report")
	public ModelAndView showReport() {
		ModelAndView mv = new ModelAndView();
		ReportFilms rf = new ReportFilms();
		ArrayList<AddFilm> lst = rf.getList();
		mv.addObject("filmlist", lst);
		mv.setViewName("AdminPanel");
		return mv;
	}

	@RequestMapping("/Register")
	public String createAcc() {
		return "Register";
	}

	@RequestMapping("/adduser")
	public String addfilm(User obj) {
		String Page = "";
		if (obj.addNewUser().equals("sucess"))
			Page = "NewFile";
		else
			Page = "Failure";

		return Page;
	}

	@RequestMapping("/delete")
	public String deleteFilm(AddFilm objs) {
		String page = "";
		if (objs.deleteFilm().equals("success"))
			page = "AdminPanel";
		else
			page = "failure";

		return page;
	}

	@RequestMapping("/edit")
	public ModelAndView filmEdit(HttpServletRequest request) {
		String name = request.getParameter("name");

		ModelAndView mv = new ModelAndView();
		Updatefilm uf = new Updatefilm(name);

		ArrayList<AddFilm> lst = uf.getList();
		mv.addObject("UFilm", lst);
		mv.setViewName("UpdateFilm");
		return mv;

	}

	@RequestMapping("/updatefilm")
	public String editFilmdetails(AddFilm objs) {
		String page = "";
		if (objs.editFilm().equals("success"))
			page = "AdminPanel";
		else
			page = "failure";

		return page;
	}

	@RequestMapping("/searchfilm")
	public ModelAndView fsearch(HttpServletRequest request) {
		String name = request.getParameter("fname");

		System.out.println(name);

		ModelAndView mv = new ModelAndView();
		Updatefilm uf = new Updatefilm(name);

		ArrayList<AddFilm> lst = uf.getList();
		mv.addObject("SFilm", lst);
		mv.setViewName("SearchResult");

		return mv;
	}

//  UserHome Operations Starts From here....

	@RequestMapping("/usearchfilm")
	public ModelAndView ufsearch(HttpServletRequest request) {
		String name = request.getParameter("fname");
		String category = request.getParameter("category");
		String language = request.getParameter("language");
		String director = request.getParameter("director");
		String actor = request.getParameter("actor");

		System.out.println(name);
		System.out.println(category);
		System.out.println(language);
		System.out.println(director);
		System.out.println(actor);

		ModelAndView mv = new ModelAndView();
		Updatefilm uf = new Updatefilm(name, category, language, director, actor);

		ArrayList<AddFilm> lst = uf.getList();
		mv.addObject("USFilm", lst);
		
		Review re= new Review(name);
		ArrayList<AddReview> lsts = re.getList();
		mv.addObject("review", lsts);
		
		mv.setViewName("UserSearchResult");

		return mv;

	}

	@RequestMapping("/review")
	public ModelAndView review(HttpServletRequest request) 
	{
		String fname = request.getParameter("fname");
		String uname = request.getParameter("uname");
		String ureview = request.getParameter("ureview");

		System.out.println(fname);
		System.out.println(uname);
		System.out.println(ureview);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("fname", fname);
		mv.setViewName("WriteReview");
		return mv;
	}

	@RequestMapping("/addyourreview")
	public ModelAndView savRreview(HttpServletRequest request) 
	{
		String fname = request.getParameter("fname");
		String uname = request.getParameter("uname");
		String ureview = request.getParameter("ureview");

		System.out.println(fname);
		System.out.println(uname);
		System.out.println(ureview);
		
		ModelAndView mv = new ModelAndView();
		Review rv = new Review(fname, uname, ureview);
		mv.setViewName("UserHome");
		
		return mv;
}
}
