package com.filmreview.models;

import java.sql.*;
import java.util.ArrayList;

public class Updatefilm 
{
	private ArrayList<AddFilm> list;
	
	public Updatefilm(String nm)
	{
		String name=nm;
		list = new ArrayList<AddFilm>();
		
		AddFilm film;
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst=con.prepareStatement("select * from filmdetails where name=?");
			pst.setString(1, name);
			
			rs=pst.executeQuery();
			if(rs.next())
			{
				film = new AddFilm();
				film.setName(rs.getString("name"));
				film.setLanguage(rs.getString("language"));
				film.setCountry(rs.getString("country"));
				film.setCategory(rs.getString("category"));
				film.setRelyear(rs.getString("relyear"));
				film.setCertificate(rs.getString("certificate"));
				film.setDirector(rs.getString("director"));
				film.setActor(rs.getString("actor"));
				film.setAtress(rs.getString("atress"));
				film.setMusic(rs.getString("music"));
				film.setPlatform(rs.getString("platform"));
				film.setBudget(rs.getString("budget"));
				film.setCollection(rs.getString("collection"));
				film.setYouTubetrailer(rs.getString("youTubetrailer"));
				list.add(film);
				
				
			}
			con.close();			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}
	
	
	public Updatefilm(String nm, String fc,String fl,String fd, String fa)
	{
		String name=nm;
		String category=fc;
		String language=fl;
		String director=fd;
		String actor=fa;
		
		list = new ArrayList<AddFilm>();
		
		AddFilm film;
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst=con.prepareStatement("select * from filmdetails where name=? OR category=? OR language=? OR director=? OR actor=?");
			pst.setString(1, name);
			pst.setString(2, category);
			pst.setString(3, language);
			pst.setString(4, director);
			pst.setString(5, actor);
			
			rs=pst.executeQuery();
			if(rs.next())
			{
				film = new AddFilm();
				film.setName(rs.getString("name"));
				film.setLanguage(rs.getString("language"));
				film.setCountry(rs.getString("country"));
				film.setCategory(rs.getString("category"));
				film.setRelyear(rs.getString("relyear"));
				film.setCertificate(rs.getString("certificate"));
				film.setDirector(rs.getString("director"));
				film.setActor(rs.getString("actor"));
				film.setAtress(rs.getString("atress"));
				film.setMusic(rs.getString("music"));
				film.setPlatform(rs.getString("platform"));
				film.setBudget(rs.getString("budget"));
				film.setCollection(rs.getString("collection"));
				film.setYouTubetrailer(rs.getString("youTubetrailer"));
				list.add(film);
				
				
			}
			con.close();			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}

	public ArrayList<AddFilm> getList() {
		// TODO Auto-generated method stub
		return list;
	}

}
