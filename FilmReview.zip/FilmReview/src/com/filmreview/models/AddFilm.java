package com.filmreview.models;

import java.sql.*;

import org.springframework.beans.factory.annotation.Autowired;


public class AddFilm 
{
	private int id;
	
	@Autowired
	private String name;
	private String language;
	private String country;
	private String category;
	private String relyear;
	private String certificate;
	private String director;
	private String actor;
	private String atress;
	private String music;
	private String platform;
	private String budget;
	private String collection;
	private String YouTubetrailer;
	
	@Autowired
	public AddFilm()
	{
		id=0;
		name="";
		language="";
		country="";
		category="";
		relyear="";
		certificate="";
		director="";
		actor="";
		atress="";
		music="";
		platform="";
		budget="";
		collection="";
		YouTubetrailer="";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	@Autowired
	public void setName(String name) {
		this.name = name;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getRelyear() {
		return relyear;
	}

	public void setRelyear(String relyear) {
		this.relyear = relyear;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public String getAtress() {
		return atress;
	}

	public void setAtress(String atress) {
		this.atress = atress;
	}

	public String getMusic() {
		return music;
	}

	public void setMusic(String music) {
		this.music = music;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getBudget() {
		return budget;
	}

	public void setBudget(String budget) {
		this.budget = budget;
	}

	public String getCollection() {
		return collection;
	}

	public void setCollection(String collection) {
		this.collection = collection;
	}

	public String getYouTubetrailer() {
		return YouTubetrailer;
	}

	public void setYouTubetrailer(String youTubetrailer) {
		YouTubetrailer = youTubetrailer;
	}
	
	public String addFilmdeatils()
	{
		String stat="";
		
		Connection con;
		PreparedStatement pst;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst=con.prepareStatement("insert into filmdetails(name,language,country,category,relyear,certificate,director,actor,atress,music,platform,budget,collection,YouTubetrailer) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
			pst.setString(1, name);
			pst.setString(2, language);
			pst.setString(3, country);
			pst.setString(4, category);
			pst.setString(5, relyear);
			pst.setString(6, certificate);
			pst.setString(7, director);
			pst.setString(8, actor);
			pst.setString(9, atress);
			pst.setString(10, music);
			pst.setString(11, platform);
			pst.setString(12, budget);
			pst.setString(13, collection);
			pst.setString(14, YouTubetrailer);
			
			pst.executeUpdate();
			stat="success";
			con.close();
		}
		catch(Exception e)
		{
			stat="error";
			System.out.println(e);
		}
		
		return stat;
	}
	
	public String deleteFilm()
	{
		String stat="";
		Connection con;
		PreparedStatement pst;
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst=con.prepareStatement("delete from filmdetails where name=?;");
			pst.setString(1, name);
			pst.executeUpdate();
			stat="success";
			con.close();
		}
		
		catch(Exception e)
		{
			stat="error";
			System.out.println(e);
		}
		
		
		return stat;
	}
	
	
	
	public String editFilm()
	{
		String stat="";
		
		Connection con;
		PreparedStatement pst;
		
		
		System.out.println(language);
		System.out.println(country);
		System.out.println(category);
		System.out.println(relyear);
		System.out.println(certificate);
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println(name);

		
		
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst=con.prepareStatement("update filmdetails set language=?,country=?,category=?,relyear=?,certificate=?,director=?,actor=?,atress=?,music=?,platform=?,budget=?,collection=?,YouTubetrailer=? where name=?;");
			
			pst.setString(1, language);
			pst.setString(2, country);
			pst.setString(3, category);
			pst.setString(4, relyear);
			pst.setString(5, certificate);
			pst.setString(6, director);
			pst.setString(7, actor);
			pst.setString(8, atress);
			pst.setString(9, music);
			pst.setString(10, platform);
			pst.setString(11, budget);
			pst.setString(12, collection);
			pst.setString(13, YouTubetrailer);
			pst.setString(14, name);
			
			pst.executeUpdate();
			stat="success";
			con.close();
		}
		catch(Exception e)
		{
			stat="error";
			System.out.println(e);
			e.printStackTrace();
		}
		
		return stat;
	}

}
