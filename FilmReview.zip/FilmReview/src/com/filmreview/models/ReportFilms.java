package com.filmreview.models;

import java.sql.*;
import java.util.ArrayList;

public class ReportFilms 
{
	private ArrayList<AddFilm> list;
	
	public ReportFilms() 
	{
		list=new ArrayList<AddFilm>();
		AddFilm film;
		
		Connection con;
		Statement st;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			st=con.createStatement();
			rs=st.executeQuery("select * from filmdetails;");
			
			while(rs.next())
			{
				film=new AddFilm();
				film.setName(rs.getString("name"));
				film.setLanguage(rs.getString("language"));
				film.setCountry(rs.getString("country"));
				film.setCategory(rs.getString("category"));
				film.setRelyear(rs.getString("relyear"));
				film.setCertificate(rs.getString("certificate"));
				film.setDirector(rs.getString("director"));
				film.setActor(rs.getString("actor"));
				film.setAtress(rs.getString("atress"));
				film.setMusic(rs.getString("music"));
				film.setPlatform(rs.getString("platform"));
				film.setBudget(rs.getString("budget"));
				film.setCollection(rs.getString("collection"));
				film.setYouTubetrailer(rs.getString("youTubetrailer"));
				list.add(film);
			}
		con.close();	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	public ArrayList<AddFilm> getList() {
		return list;
	}


}
