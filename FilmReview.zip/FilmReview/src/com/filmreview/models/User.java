package com.filmreview.models;

import java.sql.*;


public class User 
{
	private String name;
	private String mail;
	private String mobile;
	private String pas;
	private String age;
	private String gender;
	private String city;
	private String type;
	private String status;
	
	public User()
	{
		name="";
		mail="";
		mobile="";
		pas="";
		age="";
		gender="";
		city="";
		type="";
		status="";
	}
	
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPas() {
		return pas;
	}

	public void setPas(String pas) {
		this.pas = pas;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String checkUser()
	{
   		 String stat="";
		 Connection con;
		 PreparedStatement pst;
		 ResultSet rs;
		 
		 try
		 {
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			 pst=con.prepareStatement("select * from user where mobile=? and password=? and status='active'");
			 pst.setString(1, mobile);
			 pst.setString(2, pas);
			 rs=pst.executeQuery();
			 if(rs.next())
			 {
				 String typ=rs.getString("type");
					if(typ.equals("admin"))
					 stat="admin";
				 else
					 stat="customer";
				
				// stat="sucess";
			 }
			 else
			 {
					stat="faield";
			 }
			 con.close();
		 }
		 catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return stat;
	}
	
	public String addNewUser()
	{
		String stat="";
		Connection con;
		PreparedStatement pst;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst=con.prepareStatement("insert into user values(?,?,?,?,?,?,?,default,default);");
			pst.setString(1, name);
			pst.setString(2, mail);
			pst.setString(3, mobile);
			pst.setString(4, pas);
			pst.setString(5, age);
			pst.setString(6, gender);
			pst.setString(7, city);
			pst.executeUpdate();
			stat="sucess";
			con.close();
		}
		catch(Exception e)
		{
			stat="error";
			System.out.println(e);
		}
		
		
		return stat;
	}
	
}
