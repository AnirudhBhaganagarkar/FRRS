package com.filmreview.models;

public class AddReview 
{
	private String fname;
	private String uname;
	private String ureview;
	
	public AddReview()
	{
		fname="";
		uname="";
		ureview="";
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUreview() {
		return ureview;
	}

	public void setUreview(String ureview) {
		this.ureview = ureview;
	}
	

}
