package com.filmreview.models;


import java.sql.*;
import java.util.ArrayList;

public class searchFilm 
{
	private ArrayList<AddFilm> list;
	
	public searchFilm(String nm)
	{
		String name=nm;
		
		list = new ArrayList<AddFilm>();
		
		AddFilm film;
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try 
		{
			Class.forName("com.mysql.cj.jdcb.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
	//		pst=con.preparedStatement("select * from filmdetails where");
		}
		catch(Exception e)
		{
			
		}
	}
}
