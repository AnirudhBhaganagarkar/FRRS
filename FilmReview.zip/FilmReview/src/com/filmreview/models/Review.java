package com.filmreview.models;

import java.sql.*;
import java.util.ArrayList;

public class Review {
	public Review(String fname, String uname, String ureview) {
		String nam = fname;
		String name = uname;
		String review = ureview;

		Connection con;
		PreparedStatement pst;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst = con.prepareStatement("insert into review values(?,?,?)");
			pst.setString(1, nam);
			pst.setString(2, name);
			pst.setString(3, review);
			pst.executeUpdate();

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	private ArrayList<AddReview> list;

	public Review(String fname) {
		String nam = fname;

		list = new ArrayList<AddReview>();

		AddReview freview;

		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/film?user=root&password=Microsoft");
			pst = con.prepareStatement("select * from review where fname=?");
			pst.setString(1, nam);
			rs=pst.executeQuery();
			if(rs.next())
			{
				freview = new AddReview();
				
				freview.setUname(rs.getString("uname"));
				freview.setUreview(rs.getString("ureview"));
				list.add(freview);
			}

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public ArrayList<AddReview> getList() {
		// TODO Auto-generated method stub
		return list;
	}

}
